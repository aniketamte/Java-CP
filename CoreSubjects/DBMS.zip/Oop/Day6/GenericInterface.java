

public interface GenericInterface<T> {
      void display(T value);
}

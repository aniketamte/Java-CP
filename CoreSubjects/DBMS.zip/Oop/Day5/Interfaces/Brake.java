package Interfaces;

public interface Brake {
      void brake();
}

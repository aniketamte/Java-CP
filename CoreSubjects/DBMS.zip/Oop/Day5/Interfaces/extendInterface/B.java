package Interfaces.extendInterface;

public interface B {
      void greet();
      //void fun();
}

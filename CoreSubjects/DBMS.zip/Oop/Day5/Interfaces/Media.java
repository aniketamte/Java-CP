package Interfaces;

public interface Media {
      void start();
      void stop();
}

// package Interfaces.NestedInterface;
// public class A {
//       //Nested interface
//       public interface NestedInterface{
//             boolean isOdd(int num);
//       }
// }

// class B implements A.NestedInterface{

// }
